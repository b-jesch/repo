from handler import ContextHandler as ch

if __name__ == '__main__':
    ch().mark_item()
